﻿using System.Diagnostics.Tracing;
using System.Collections.Generic;
using System;
using System.Text;
using System.Threading.Tasks;

using System.Linq;

namespace LinqFinalAssignment;

class Program
{
    public static void Main(string[] args)
    {
        TraineeData trainee = new TraineeData();
        TraineeScore traineeScore = new TraineeScore();
       // TraineeData traineeData = new TraineeData();

        List<TraineeDetails> traineeList = trainee.GetTraineeDetails();


        int option;
        System.Console.WriteLine("Enter one among the following \n");
        System.Console.WriteLine("Press 1 to Show the list of Trainee Id \n");
        System.Console.WriteLine("Press 2 to Show the first 3 Trainee Id using Take \n");
        System.Console.WriteLine("Press 3 to show the last 2 Trainee Id using Skip\n");
        System.Console.WriteLine("Press 4 to show the count of Trainee \n");
        System.Console.WriteLine("Press 5 to show the Trainee Name who are all passed out 2019 or later \n");
        System.Console.WriteLine("Press 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name. \n");
        System.Console.WriteLine("Press 7 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark who are all scores the more than or equal to 4 mark \n");
        System.Console.WriteLine("Press 8 to show the unique passed out year using distinct \n");
        System.Console.WriteLine("Press 9 to show the total marks of single user (get the Trainee Id from User), if Trainee Id does not exist, show the invalid message \n");
        System.Console.WriteLine("Press 10 to show the first Trainee Id and Trainee Name \n");
        System.Console.WriteLine("Press 11 to show the last Trainee Id and Trainee Name \n");
        System.Console.WriteLine("Press 12 to print the total score of each trainee \n");
        System.Console.WriteLine("Press 13 to show the maximum total score \n");
        System.Console.WriteLine("Press 14 to show the minimum total score \n");
        System.Console.WriteLine("Press 15 to show the average of total score \n");
        System.Console.WriteLine("Press 16 to show true or false if any one has the more than 40 score using any() \n");
        System.Console.WriteLine("Press 17 to show true of false if all of them has the more than 20 using all() \n");
        System.Console.WriteLine("Press 18 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark by show the Trainee Name as descending order and then show the Mark as descending order. \n");

        
        option=int.Parse(Console.ReadLine());
        switch(option)
        {
            case 1 :
                {
                    System.Console.WriteLine("Press 1 to Show the list of Trainee Id \n");
                    var traineeID = from trainees in traineeList select(trainees.TraineeId);

                    foreach(var i in traineeID)
                    {
                        System.Console.WriteLine(i + "\n");
                    }
                                    
                    break;
                }

            case 2 :
                {
                    System.Console.WriteLine("Press 2 to Show the first 3 Trainee Id using Take \n");

                    var traineeID = from trainees in traineeList.Take(3) select(trainees.TraineeId);
                    foreach(var i in traineeID)
                    {
                        System.Console.WriteLine(i+ "\n");
                    }
                    break;
                }

            case 3 :
                {
                    System.Console.WriteLine("\n \nPress 3 to show the last 2 Trainee Id using Skip\n");
                    var traineeID = from trainees in traineeList.Skip(3) select(trainees.TraineeId);
                    foreach(var i in traineeID)
                    {
                        System.Console.WriteLine(i + "\n");
                    }

                    break;
                }

            case 4 :
                {

                    System.Console.WriteLine("Press 4 to show the count of Trainee \n");
                    var data = from trainees in traineeList select(trainees);
                    int dataCount=0;

                    foreach(var datas in data)
                    {
                        dataCount++;
                    }
                    System.Console.WriteLine("the trainee count is " + dataCount);
                    break;
                }

            case 5 :
                {
                            
                    System.Console.WriteLine("\n \nPress 5 to show the Trainee Name who are all passed out 2019 or later \n");
                    var data = from trainees in traineeList where  trainees.YearPassedOut >= 2019 select(trainees.TraineeName);

                    foreach(var i in data )
                    {
                        System.Console.WriteLine(i + "/n");
                    }

                    
                    break;
                }

            case 6:
                {
                    System.Console.WriteLine("\n \nPress 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name. \n");
                    var data = from trainees in traineeList orderby trainees.TraineeName select(trainees.TraineeId , trainees.TraineeName);
                    foreach(var i in data)
                    {
                        System.Console.WriteLine(i + "\n");
                    }


                    break;
                }

            case 7 :
                {
                    System.Console.WriteLine("Press 7 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark who are all scores the more than or equal to 4 mark \n");
                    var data = from trainees in traineeList select(trainees);

                    foreach(var i in data)
                    {
                        foreach(var j in  i.ScoreDetails)
                        {
                            if(j.Mark>=4)
                            {
                                System.Console.WriteLine($"|| {i.TraineeId} || {i.TraineeName} || {j.TopicName} || {j.ExerciseName} || {j.Mark} ||");
                            }
                        }
                    }
                    break;
                }

            case 8:
                {
                            
                    System.Console.WriteLine("\n \nPress 8 to show the unique passed out year using distinct \n");
                    var data = (from trainees in traineeList select trainees.YearPassedOut).Distinct();
                    foreach(var i in data)
                    {
                        System.Console.WriteLine(i + "\n");
                    }
                    break;
                }

            case 9:
            {
                System.Console.WriteLine("Press 9 to show the total marks of single user (get the Trainee Id from User), if Trainee Id does not exist, show the invalid message \n");
                System.Console.WriteLine("\n \nEnter your training ID \n");
                string enteredID = Console.ReadLine().ToUpper();

                var data = from trainees in traineeList
                                   select trainees;
                        int totalMark = 0;
                        System.Console.WriteLine("Enter Your Traniee ID : ");
                        string TranieeID = Console.ReadLine().ToUpper();

                        int temp = 0;
                        foreach (var trainees in data)
                        {
                            if (TranieeID == trainees.TraineeId)
                            {
                                temp = 1;
                                foreach (var scores in trainees.ScoreDetails)
                                {
                                    totalMark += scores.Mark;
                                }

                            System.Console.WriteLine("Total Mark of the " + TranieeID + "is " + totalMark);
                            }
                           
                        }

                        if (temp == 0)
                        {
                            System.Console.WriteLine("Invalid Traniee ID ");
                        }

                break;
            }

            case 10 :
            {
                System.Console.WriteLine("\n \nPress 10 to show the first Trainee Id and Trainee Name \n");
                var data = from trainees in traineeList.Take(1) select(trainees.TraineeId , trainees.TraineeName);
                foreach(var i in data)
                {
                    System.Console.WriteLine(i + "\n");
                }

                break;
            }

            case 11 :
                {

                    System.Console.WriteLine("\n \nPress 11 to show the last Trainee Id and Trainee Name \n");
                    var data = from trainees in traineeList.TakeLast(1) select(trainees.TraineeId , trainees.TraineeName);
                    foreach(var i in data)
                    {
                        System.Console.WriteLine(i + "\n");
                    }
                    break;
                }

            case 12 :
                {

                    System.Console.WriteLine("\n \nPress 12 to print the total score of each trainee \n");
                    var data = from trainees in traineeList
                                   select trainees;

                        foreach (var trainees in data)
                        {
                            int totalScore = 0;
                            foreach (var scores in trainees.ScoreDetails)
                            {
                                totalScore += scores.Mark;
                            }
                            System.Console.WriteLine("Trainee ID : " + trainees.TraineeId + " Total Mark : " + totalScore);
                        }

                        break;
                }

            case 13:
                {
                    
                    System.Console.WriteLine("\n \nPress 13 to show the maximum total score \n");
                    var data = from trainees in traineeList
                                    select trainees;
                            var list = new List<int>();
                            foreach (var trainees in data)
                            {
                                int totalScore = 0;
                                foreach (var scores in trainees.ScoreDetails)
                                {
                                    totalScore += scores.Mark;
                                }
                                System.Console.WriteLine("Trainee ID : " + trainees.TraineeId + " Total Mark : " + totalScore);
                                list.Add(totalScore);
                            }
                            var maxNumber = (from x in list select x).Max();
                            System.Console.WriteLine("Maximum Total Score : " + maxNumber);


                    break;
                }

            case 14 :
                {
                    System.Console.WriteLine("\n \nPress 14 to show the minimum total score \n");
                    var data = from trainees in traineeList
                                    select trainees;
                            var list = new List<int>();
                            foreach (var trainees in data)
                            {
                                int totalScore = 0;
                                foreach (var scores in trainees.ScoreDetails)
                                {
                                    totalScore += scores.Mark;
                                }
                                System.Console.WriteLine("Trainee ID : " + trainees.TraineeId + " Total Mark : " + totalScore);
                                list.Add(totalScore);
                            }
                            var minNumber = (from x in list select x).Min();
                            System.Console.WriteLine("Maximum Total Score : " + minNumber);


                    
                    break;
                }

            case 15:
                {
                    System.Console.WriteLine("\n \nPress 15 to show the average of total score \n");

                
                    var data = from trainees in traineeList
                                select trainees;
                    double sum = 0;
                    foreach (var trainees in data)
                    {
                        int totalScore = 0;
                        foreach (var scores in trainees.ScoreDetails)
                        {
                            totalScore += scores.Mark;
                        }
                        sum += totalScore;
                        System.Console.WriteLine("Trainee ID : " + trainees.TraineeId + " Total Mark : " + totalScore);
                    }
                    double average = sum / data.Count();
                    System.Console.WriteLine("The Average of totalScore : " + average);
                    break;
                }

            case 16:
                    {
                        System.Console.WriteLine("\n \nPress 16 to show true or false if any one has the more than 40 score using any() \n");
       

                
                        var data = from trainees in traineeList
                                   select trainees;

                        var list = new List<int>();

                        foreach (var trainees in data)
                        {
                            int totalScore = 0;
                            foreach (var scores in trainees.ScoreDetails)
                            {
                                totalScore += scores.Mark;
                            }
                            System.Console.WriteLine("Trainee ID : " + trainees.TraineeId + " Total Mark : " + totalScore);
                            list.Add(totalScore);
                        }
                        var numbers = (from x in list
                                       select x).Any(s => s >= 40);
                        System.Console.WriteLine("Total Value greater than or Equal to 40 : " + numbers);
                        break;
                    }
            case 17:
                    {

                        System.Console.WriteLine("\n \nPress 17 to show true of false if all of them has the more than 20 using all() \n");

                        var data = from trainees in traineeList
                                    select trainees;

                        var list = new List<int>();

                        foreach (var trainees in data)
                        {
                            int totalScore = 0;
                            foreach (var scores in trainees.ScoreDetails)
                            {
                                totalScore += scores.Mark;
                            }
                            System.Console.WriteLine("Trainee ID : " + trainees.TraineeId + " Total Mark : " + totalScore);
                            list.Add(totalScore);
                        }
                        var numbers = (from x in list
                                        select x).All(s => s >= 20);
                        System.Console.WriteLine("Total Value greater than or Equal to 20 : " + numbers);
                        break;

                    }
            case 18:
                    {

                        System.Console.WriteLine("\n \nPress 18 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark by show the Trainee Name as descending order and then show the Mark as descending order. \n");


                        var data = from id in traineeList
                                   orderby id.TraineeName descending
                                   from marks in id.ScoreDetails
                                   orderby marks.Mark descending
                                   select new { id.TraineeId, id.TraineeName, marks.TopicName, marks.ExerciseName, marks.Mark };
                        foreach (var item in data)
                        {
                            System.Console.WriteLine($"Tranee Name :{item.TraineeName}\t Trainee id :{item.TraineeId}\t TopicName:{item.TopicName} Excercise Name:{item.ExerciseName} Mark:{item.Mark} ");
                        }
                        break;
                    }

            
        }


    }
}
